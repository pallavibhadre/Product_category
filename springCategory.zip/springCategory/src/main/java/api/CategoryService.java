package api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Jbk.service.ProductServiceImpl;
import com.jbk.dao.StudentDao;
import com.jbk.dao.StudentDaoImpl;
import com.jbk.entity.Student;

@Service
public class CategoryService implements CategoryServiceImpl{
	
	@Autowired
	CategoryDaoImpl catDaoImpl;
	
	public Category getCategoryService(int id) {
		return catDaoImpl.getCategoryDao(id);
	}
	
	public List<Category> getCategorysService(){
		return catDaoImpl.getCategorysDao();
	}
	
	public String addCategoryService(Category pro) {
		return catDaoImpl.addCategoryDao(pro);
	}
	
	public String deleteCategoryService(int id) {
		return catDaoImpl.deleteCategoryDao(id);
	}
	
	public String updateCategoryService(int id, Category pro) {
		return catDaoImpl.updateCategoryDao(id,pro);
	}
}
