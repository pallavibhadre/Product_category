package api;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Jbk.dao.ProductDaoImpl;
import com.jbk.entity.Student;

@Repository
public class Category Dao implements CategoryDaoImpl {

	@Autowired
	SessionFactory sessionFactory;

	public Category getCategoryDao(int id) {
		Session session = sessionFactory.openSession();
		Category pro = session.get(Category.class, id);

		return pro;
	}

	public List<Category> getCategorysDao() {
		Session session = sessionFactory.openSession();

		Criteria criteria = session.createCriteria(Category.class);
		List<Category> products = criteria.list();
		return products;
	}

	public String addCategoryDao(Category pro) {
		try {
			Session session = sessionFactory.openSession();

			session.save(pro);
			session.beginTransaction().commit();
			return "Category  added";
		} catch (Exception ex) {
			return "Error occured while adding Category  : " + ex.getMessage();
		}
	}

	public String deleteCategoryDao(int id) {
		try {

			Session session = sessionFactory.openSession();
			Category pro = session.get(Category.class, id);

			if (pro == null) {
				return "Category  not found";
			}

			session.delete(pro);
			session.beginTransaction().commit();
			return "Category  deleted";
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			return "Error occured while deleting Category  : " + ex.getMessage();
		}
	}

	public String updateCategoryDao(int id, Category student) {
		Session session = sessionFactory.openSession();
		Category pro1 = session.get(Category.class, id);

		if (pro1 == null) {
			return "Category  not found";
		}
		
	pro1.setId(pro.getId());
		pro1.setName(pro.getName());
		
		session.update(pro1);
		session.beginTransaction().commit();
		return "Category updated";
	}

	
}
