package api;

import java.util.List;

import com.Jbk.entity.Product;
import com.jbk.entity.Student;

public interface CategoryDaoImpl {

	Category getCategoryDao(int id);
	List<Category> getCategoryDao();
	String addCategoryDao(Category pro);
	String deleteCategoryDao(int id);
	String updateCategoryDao(int id, Category pro);
}
