package api;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Jbk.service.ProductServiceImpl;
import com.jbk.entity.Student;
import com.jbk.service.StudentService;
import com.jbk.service.StudentServiceImpl;

@RestController
public class CategoryController {
	
	@Autowired
	CategoryServiceImpl catServiceImpl;	
	
	@GetMapping("/Category/{id}")
	Category getCategory (@PathVariable int id) {
		return catServiceImpl.getCategoryService(id);
	}

	@GetMapping("/Category ")
	List<Category> getStudents() {
		
		return catServiceImpl.getCategorysService();
	}

	@PostMapping("/Category ")
	String addCategory (@RequestBody Category pro) {
		return catServiceImpl.addCategoryService(pro);
	}
	
	@DeleteMapping("/Category /{id}")
	String deleteCategory (@PathVariable int id) {
		return catServiceImpl.deleteCategoryService(id);
	}
	
	@PutMapping("/Category /{id}")
	String updateCategory (@PathVariable int id, @RequestBody Category pro) {
		return catServiceImpl.updateCategoryService(id, pro);
	}
}
