package api;

import java.util.List;

import com.jbk.entity.Student;

public interface CategoryServiceImpl {
	Category getCategoryService(int id);

	List<Category> getCategorysService();

	String addCategoryService(Category pro);

	String deleteCategoryService(int id);
	
	String updateCategorytService(int id, Category pro);
}
